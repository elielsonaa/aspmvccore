﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleMonitor
{
    class Program
    {
        static void Main(string[] args)
        {
            int Tempo, TempoAnt = 5;
            Console.Title = "                     Monitor de Eventos COPAVE                       ";
            StringBuilder Cabecalho = new StringBuilder();
            Cabecalho.Append("\t\t###########################################################################################\n");
            Cabecalho.Append("\t\t###########################################################################################\n");
            Cabecalho.Append("\t\t##############    Monitor de  Eventos do Sistema Copave de Cadastro    ####################\n");
            Cabecalho.Append("\t\t##############       DEsenvolvido por Elielson de Azevedo Andrade      ####################\n");
            Cabecalho.Append("\t\t###########################################################################################\n");
            Cabecalho.Append("\t\t########  Se o Banco de dados não foi feito plelo script que acompanha o sistema   ########\n");
            Cabecalho.Append("\t\t#########            Será necessário reconfigurar a string de conexão             #########\n");
            Cabecalho.Append("\t\t###########################################################################################\n");
            Cabecalho.Append("\n\n");
            
            Console.WriteLine(Cabecalho.ToString());
            Console.WriteLine("O sistema consulta a base de monitoramento a cada 5 minutos....");
            Console.WriteLine("Se desejar definir um tempo diferente de 5 minutos? informe abaixo: ");
            bool numOk = Int32.TryParse(Console.ReadLine(), out Tempo);
            if (!numOk)
            {
                Console.WriteLine(" Valor informado é inválido. O sistema considerará o valor padrão.");
                Tempo = TempoAnt;
            }
            Console.WriteLine("O Sistema atualizará os eventos a cada {0} minutos.... iniciando em:"+ DateTime.Now.ToString("h:mm:ss"),Tempo);
            Tempo = (Tempo * 60000);
            BuscarDados();
            TimerCallback retorno = new TimerCallback(Tick);
            Timer initTime = new Timer(retorno, null, 0, Tempo);
            Console.Read();
        }
        static public void Tick(Object stateInfo)
        {
            Console.WriteLine("Log extraido em : {0}", DateTime.Now.ToString("h:mm:ss"));
            BuscarDados();
        }
        static void BuscarDados()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connCopave))
                {
                    Console.WriteLine("\t\tInciciando consulta das alteraçõe do dia:" + DateTime.Now.ToString("dd/MM/yyyy")+"\n");
                    Console.WriteLine("\t\t###########################################################################################\n");
                    connection.Open();
                    String sql = "SELECT Data_Evento, Hostname,"+
                                     "case when Evento = 'UPDATE' then 'Alteracao'"+
                                         "when Evento = 'INSERT' then 'Inclusao'"+
                                         "when Evento = 'DELETE' then 'Exlusao'"+
			                         "else 'Outro' end as Evento,Descricao "+
                                 "From dbo.Maquina_log "+
                                 " where convert(date,Data_Evento,3)=convert(date,getdate(),3)";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Console.WriteLine("Data: {0} - Do Computador: {1} - Houve uma: {2} - Na maquina: {3}", reader.GetDateTime(0).ToString(), reader.GetString(1), reader.GetString(2), reader.GetString(3));
                            }
                        }
                    }
                }
            }
            catch (SqlException e)
            {
                Console.WriteLine(e.ToString());
            }
            Console.WriteLine("\nPressione qualquer tecla para encerrar o monitoramento.");
            Console.ReadLine();
        }
    }
}
